<a href="/" title="http://osmanmoharram">
    <img
        src="{{ asset('img/me.svg') }}"
        alt="logo"
        class="w-[75] h-[75]"
    >
</a>
