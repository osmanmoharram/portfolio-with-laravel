<x-app-layout>
    <x-slot name="title">Osman Moharram - Home</x-slot>
    @include('includes.sections.hero')

    @include('includes.sections.services')

    @include('includes.sections.projects')

    @include('includes.sections.contact')
</x-app-layout>
