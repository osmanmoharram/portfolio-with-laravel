<a href="/" title="http://osmanmoharram">
    <img
        src="<?php echo e(asset('img/me.svg')); ?>"
        alt="logo"
        class="w-[75] h-[75]"
    >
</a>
<?php /**PATH C:\Apache24\htdocs\osmanmoharram\resources\views/components/logo.blade.php ENDPATH**/ ?>