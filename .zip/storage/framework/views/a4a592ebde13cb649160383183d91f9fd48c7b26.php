<!-- Slider main container -->
<div class="swiper lg:h-[400px]">
    <!-- Additional required wrapper -->
    <div class="swiper-wrapper h-fit">
        <!-- Slides -->
        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="swiper-slide bg-center bg-cover rounded-[10px] border dark:border-none overflow-hidden">
                <img src="<?php echo e($image); ?>" alt="" class="h-full">
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <!-- If we need pagination -->
    <div class="swiper-pagination"></div>

    <!-- If we need navigation buttons -->
    <div class="swiper-button-prev"></div>
    <div class="swiper-button-next"></div>

    <!-- If we need scrollbar -->
    <div class="swiper-scrollbar"></div>
</div>
<?php /**PATH C:\Apache24\htdocs\osmanmoharram\resources\views/includes/carousel.blade.php ENDPATH**/ ?>