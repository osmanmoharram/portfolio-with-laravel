<?php $__env->startComponent('mail::message'); ?>
# Reach Me Message

###### Email: <?php echo e($message->email); ?>


<?php echo e($message->body); ?>


Thanks,<br>
<?php echo e($message->sender); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Apache24\htdocs\osmanmoharram\resources\views/mail/reach-me-message.blade.php ENDPATH**/ ?>