[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH C:\Apache24\htdocs\osmanmoharram\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>