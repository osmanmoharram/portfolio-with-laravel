<?php $attributes = $attributes->exceptProps(['image']); ?>
<?php foreach (array_filter((['image']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="hover:shadow-lg flex-shrink-0 flex flex-col w-72 h-[380px] p-12 rounded-[10px] border bg-gray-50 tracking-wide hover:scale-110 transition-all duration-150 ease-out dark:bg-slate-800 dark:border-slate-700">
    <img class="h-64" src="<?php echo e($image); ?>" <?php echo e($attributes); ?>>

    <span class="text-base text-center mt-16"><?php echo e($slot); ?></span>
</div>
<?php /**PATH C:\Apache24\htdocs\osmanmoharram\resources\views/components/card.blade.php ENDPATH**/ ?>