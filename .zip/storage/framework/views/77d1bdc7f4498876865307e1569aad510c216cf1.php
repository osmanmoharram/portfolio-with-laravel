<?php echo e($slot); ?>

<?php /**PATH C:\Apache24\htdocs\osmanmoharram\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>